# Phase 94 Validation Protocol

## Preconditions

From `01-runtime\next-e2e`:

```powershell
npm run build
npm run start
```

Keep the production server running.

## A. Automated server proof

From another PowerShell:

```powershell
.\validate-dynamic-ssr.ps1
```

Expected:

```json
{
  "status": "PASS",
  "requestTimeCookiePersonalization": true,
  "sameRouteDifferentServerOutput": true
}
```

The two expected identities are:

```text
ar-EG.luxury.smooth → ar-EG::luxury::smooth
en-US.light.instant → en-US::light::instant
```

## B. Browser proof

Open:

```text
http://localhost:3000/personalized
```

Then use DevTools/Application/Cookies or the console to set:

```js
document.cookie = "experience=ar-EG.luxury.smooth; Path=/";
location.reload();
```

The server-rendered page should show:

```text
ar-EG
luxury
smooth
rtl
```

Change the cookie to:

```js
document.cookie = "experience=en-US.light.instant; Path=/";
location.reload();
```

The server-rendered page should instead show:

```text
en-US
light
instant
ltr
```

The important proof is the raw HTTP response, not just the post-hydration DOM.

## Interpretation

This phase upgrades the Next.js validation from:

```text
Server Component / RSC output
+
client hydration/runtime switching
```

to:

```text
request cookie
↓
dynamic server rendering
↓
ExperienceEngine resolution
↓
personalized initial HTML
↓
client hydration
↓
runtime transition
```

A local successful run should be recorded as:

```text
dynamic_per_request_ssr = PASS_WITH_SCOPE
```

because this validates the tested Next.js production setup, not every possible Next.js deployment/cache/CDN topology.
