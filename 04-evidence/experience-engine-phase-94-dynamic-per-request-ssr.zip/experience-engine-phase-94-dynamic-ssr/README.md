# Experience Engine — Phase 94
## Personalized Dynamic per-request SSR

Goal:
Demonstrate that the same Next.js App Router URL can produce different initial Experience Engine HTML on different HTTP requests, based on a request cookie, before client hydration.

This extends the validated Next.js RSC + hydration path with request-time personalization.

### Expected flow

Request A
- Cookie: `experience=ar-EG.luxury.smooth`
- Server reads cookie
- Experience Engine resolves `ar-EG / luxury / smooth`
- Server HTML contains that resolved experience

Request B
- Same URL
- Cookie: `experience=en-US.light.instant`
- Server reads cookie
- Experience Engine resolves `en-US / light / instant`
- Server HTML contains that resolved experience

The proof is not based on client-side JavaScript. The validation script inspects the raw HTTP response body.

### Scope

PASS criteria:
1. HTTP status is 200 for both requests.
2. The same `/personalized` route returns different server-side experience identities for the two cookies.
3. Each response contains the exact culture, theme, motion and direction implied by its cookie.
4. The response is generated from request-time cookie state, not from a build-time constant.

This does not claim:
- universal SSR performance superiority,
- all Next.js deployment modes,
- CDN/cache configuration correctness for every hosting provider,
- third-party replication.

After this phase, `dynamic_per_request_ssr` can be marked PASS_WITH_SCOPE if the local production validation succeeds.
