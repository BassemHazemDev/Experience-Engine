# Phase 91 — Venue Facts

Checked: 2026-09-17

Official EICS 2027 Full Papers & Technical Notes call confirms:
- Full Papers and Technical Notes are accepted.
- Technical Notes are focused system/technical contributions.
- Technical Notes require an illustrative example.
- Validation may use simulation, feasibility, or comparisons.
- There is no stated page-length restriction for Full Papers or Technical Notes.
- Submissions use ACM TAPS and the Precision Conference System.
- Review is double-blind.
- The PACM-EICS model has three submission deadlines per year.

The currently retrieved official call does not expose a concrete active 2027 round deadline,
so the deadline must be read from the live PCS submission form rather than guessed.
