# Phase 91 — PCS Execution Guide

## Target
ACM EICS 2027 — Full Papers & Technical Notes

## 1. Create the submission in PCS
Use the current EICS 2027 submission round shown in the PCS account.
Do not manually invent a round number or deadline.

## 2. Enter bibliographic metadata

### Title
Experience Engine: A Framework-Agnostic Protocol for Multi-Dimensional UI Experience Transitions

### Submission type
Technical Note candidate.

### Authors
Enter the actual authors exactly as they should appear in the final publication.
The anonymous PDF must remain anonymous.

### Affiliations / contacts
Enter the actual affiliations and contact details in PCS.

### Conflicts
Enter all required conflict-of-interest information directly in PCS.

### Abstract and keywords
Copy them from the final manuscript and re-check punctuation/formatting after paste.

## 3. Upload files

Primary review PDF:
`01-upload/Experience-Engine-EICS2027-Anonymous.pdf`

Source package:
`01-upload/experience-engine-eics2027-source.zip`

Upload the source package only when the active PCS form requests/allows source upload.

## 4. Double-blind check before submission

Confirm:
- no author names in the PDF
- no institution names in title/header
- no identifying acknowledgements
- no author metadata in the PDF
- self-citations follow the venue's anonymization rule
- no accidental identifying file names are uploaded

## 5. Research-claim check

The manuscript intentionally does NOT claim:
- first adaptive UI framework
- first multi-dimensional adaptation framework
- unique atomicity/stale-safety guarantees
- universal performance superiority

It DOES claim the narrower ETP protocol abstraction and reports scoped empirical evidence.

## 6. Final submit gate

Before clicking Submit:
- verify active round/deadline in PCS
- verify every author
- verify conflicts
- verify abstract/keywords
- verify uploaded PDF opens correctly
- verify source upload is accepted
- review all declarations
- save the PCS submission ID

## 7. After submission

Record:
- PCS submission ID
- submission round
- timestamp
- uploaded PDF SHA-256
- uploaded source ZIP SHA-256
- confirmation email/screenshot

## Current research extensions

These remain explicitly pending and must not be described as completed:
- React 18 exact E2E
- Next.js SSR/RSC runtime
- third-party independent replication
