# Experience Engine — Phase 90 Submission Handoff

Status: **READY_FOR_PCS_HANDOFF**

This package contains the exact anonymous upload PDF, clean source ZIP, PCS entry template,
submission checklist, verification record, and evidence references.

The package intentionally does not invent:
- author identities,
- affiliations,
- conflicts,
- contact data,
- an active PCS round/deadline.

Those must be entered/selected in the actual PCS account.
