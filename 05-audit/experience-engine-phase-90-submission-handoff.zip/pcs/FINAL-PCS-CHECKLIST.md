# Phase 90 — Live Submission Readiness

## Ready now
- [x] Final anonymous PDF
- [x] Clean source ZIP
- [x] PDF pages validated
- [x] Anonymous text scan
- [x] Claim/evidence gate
- [x] Venue compatibility check
- [x] Supporting evidence archived
- [x] SHA-256 integrity manifest

## Requires the submitting author in PCS
- [ ] Create/open the EICS 2027 submission in PCS
- [ ] Select the active submission round
- [ ] Enter real author identities
- [ ] Enter affiliations/contact information
- [ ] Enter conflict-of-interest information
- [ ] Paste/verify abstract and keywords
- [ ] Confirm submission type
- [ ] Upload anonymous PDF
- [ ] Upload source package only when PCS requests/allows it
- [ ] Review all generated metadata before final submission
- [ ] Recheck the active TAPS/PCS instructions immediately before submission

## Research extensions intentionally not claimed as complete
- React 18 exact E2E
- Next.js SSR/RSC runtime
- Third-party independent replication

## Final submission rule
The reviewer PDF must stay anonymous. Author identity belongs in PCS metadata, not the
anonymous manuscript.
